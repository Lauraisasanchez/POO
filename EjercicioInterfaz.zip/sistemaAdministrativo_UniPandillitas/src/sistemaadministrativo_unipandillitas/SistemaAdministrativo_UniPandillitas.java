package sistemaadministrativo_unipandillitas;

import taller.universidad.pandillitas.model.Materia;
import taller.universidad.pandillitas.roles.Administrativo;
import taller.universidad.pandillitas.service.Servicio;
import java.util.Scanner;
import taller.universidad.pandillitas.roles.Estudiante;

public class SistemaAdministrativo_UniPandillitas {

    public static void main(String[] args) {
        Administrativo admin1 = new Administrativo("Juan", "Ramirez", 100293943);
        Servicio db = new Servicio();
        Materia materia1 = new Materia("Vacio");
        Scanner entrada = new Scanner(System.in);

        System.out.println("=== Subir materias ===");
        System.out.println("Ingrese el nombre de la materia: ");
        materia1.setNombre(entrada.next());
        admin1.subirMaterias(db, materia1);
        db.mostrarMaterias();
        
        Estudiante estudiante1 = new Estudiante("","",0);
        System.out.println("=== Registrar Estudiantes ===");
        System.out.println("Ingrese el nombre del estudiante: ");
        estudiante1.setNombre(entrada.next());
        System.out.println("Ingrese el apellido del estudiante: ");
        estudiante1.setApellido(entrada.next());
        System.out.println("Ingrese el documento del estudiante: ");
        estudiante1.setDocumento(entrada.nextInt());
        admin1.regisEstudiantes(db, estudiante1);
        db.mostrarEstudiantes();
        
        String estudianteABuscar, nuevoNombre, nuevoApellido;
        int nuevoDocumento;
        System.out.println("=== Actualizar datos de Estudiantes ===");
        System.out.println("Ingrese el nombre del estudiante: ");
        estudianteABuscar = entrada.next();
        System.out.println("Ingrese el nuevo nombre del estudiante: ");
        nuevoNombre = entrada.next();
        System.out.println("Ingrese el nuevo apellido del estudiante: ");
        nuevoApellido = entrada.next();
        System.out.println("Ingrese el nuevo documento del estudiante: ");
        nuevoDocumento = entrada.nextInt();
        admin1.actualizarDatEstudiantes(db, estudianteABuscar, nuevoNombre, nuevoApellido, nuevoDocumento);
        db.mostrarEstudiantes();
    }

}
