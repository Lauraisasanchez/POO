package taller.universidad.pandillitas.service;

import java.util.LinkedList;
import taller.universidad.pandillitas.model.Materia;
import taller.universidad.pandillitas.roles.Administrativo;
import taller.universidad.pandillitas.roles.Docente;
import taller.universidad.pandillitas.roles.Estudiante;
import taller.universidad.pandillitas.roles.PadreDeFamilia;

public class Servicio {

    public static LinkedList<Materia> materias = new LinkedList<>();
    public static LinkedList<Estudiante> estudiantes = new LinkedList<>();
    public static LinkedList<Docente> docentes = new LinkedList<>();
    public static LinkedList<Administrativo> administrativos = new LinkedList<>();
    public static LinkedList<PadreDeFamilia> padresDeFamilia = new LinkedList<>();

    public void guardarMaterias(Materia materia) {
        materias.add(materia);
    }

    public void mostrarMaterias() {
        System.out.println("Lista de materias");
        for (Materia materia : materias) {
            System.out.println(materia);
        }
    }

    public void guardarEstudiantes(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public void mostrarEstudiantes() {
        System.out.println("Lista de Estudiantes");
        for (Estudiante estudiante : estudiantes) {
            System.out.println(estudiante);
        }
    }

    public void actualizarDatosEstudiante(String estudianteABuscar, String nuevoNombre, String nuevoApellido, int nuevoDocumento) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getNombre().equals(estudianteABuscar)) {
                estudiante.setNombre(nuevoNombre);
                estudiante.setApellido(nuevoApellido);
                estudiante.setDocumento(nuevoDocumento);
                break;
            }
        }
    }

}
