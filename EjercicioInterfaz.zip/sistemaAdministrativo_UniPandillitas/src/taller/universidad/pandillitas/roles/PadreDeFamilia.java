package taller.universidad.pandillitas.roles;

import taller.universidad.pandillitas.model.Persona;

public class PadreDeFamilia extends Persona {
    
    public PadreDeFamilia(String nombre, String apellido, int documento) {
        super(nombre, apellido, documento);
    }

    public void verNotasHijo() {
    }
}
