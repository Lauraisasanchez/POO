package taller.universidad.pandillitas.roles;

import taller.universidad.pandillitas.model.Persona;

public class Docente extends Persona {

    public Docente(String nombre, String apellido, int documento) {
        super(nombre, apellido, documento);
    }

    public void calificarEstudiantes() {
    }

    public void subirNotas() {
    }
}
