package taller.universidad.pandillitas.roles;

import taller.universidad.pandillitas.model.Persona;

public class Estudiante extends Persona {

    public Estudiante(String nombre, String apellido, int documento) {
        super(nombre, apellido, documento);
    }

    public void agregarNota() {
    }

    public void calificarDocentes() {
    }
    
}
