package taller.universidad.pandillitas.roles;

import taller.universidad.pandillitas.model.Materia;
import taller.universidad.pandillitas.model.Persona;
import taller.universidad.pandillitas.service.Servicio;

public class Administrativo extends Persona {
    
    public Administrativo(String nombre, String apellido, int documento) {
        super(nombre, apellido, documento);
    }
    
    public void regisEstudiantes(Servicio db, Estudiante estudiante) {
        db.guardarEstudiantes(estudiante);
    }
    
    public void actualizarDatEstudiantes(Servicio db, String estudianteABuscar, String nuevoNombre, String nuevoApellido, int nuevoDocumento) {
        db.actualizarDatosEstudiante(estudianteABuscar, nuevoNombre, nuevoApellido, nuevoDocumento);
    }
    
    public void subirMaterias(Servicio db, Materia materia) {
        db.guardarMaterias(materia);
    }
    
}
