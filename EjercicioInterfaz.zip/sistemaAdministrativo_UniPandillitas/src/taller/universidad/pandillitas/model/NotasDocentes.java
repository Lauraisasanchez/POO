package taller.universidad.pandillitas.model;

public class NotasDocentes {
    
}
