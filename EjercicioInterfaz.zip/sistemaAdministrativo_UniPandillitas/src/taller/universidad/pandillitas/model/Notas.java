package taller.universidad.pandillitas.model;

public abstract class Notas {
    private double notas;

    public Notas(double notas) {
        this.notas = notas;
    }

    public double getNotas() {
        return notas;
    }

    public void setNotas(double notas) {
        this.notas = notas;
    }
    
    
}
