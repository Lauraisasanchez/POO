package taller.universidad.pandillitas.model;

public class Materia {

    private String nombre;

    // Constructor con parametros
    public Materia(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Materia{" + "nombre=" + nombre + '}';
    }
    
}
